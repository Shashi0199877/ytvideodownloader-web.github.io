<?php


	function downloadtiktok2($URL){
		
	}

?>